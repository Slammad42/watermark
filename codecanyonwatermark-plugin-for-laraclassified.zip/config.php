<?php

return [

    // Image Upload
    'width'      => 150,
    'height'     => 150,
    'quality'    => 100,

    // Watermark Position
    'position'   => 'bottom-right', // Possible values: top-left, top, top-right, left, center, right, bottom-left, bottom, bottom-right
    'position-x' => 20,
    'position-y' => 20,

];
