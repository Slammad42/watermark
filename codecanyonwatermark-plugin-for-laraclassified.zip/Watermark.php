<?php
/**
 * LaraClassified - Geo Classified Ads CMS
 * Copyright (c) BedigitCom. All Rights Reserved
 *
 * Website: http://www.bedigit.com
 *
 * LICENSE
 * -------
 * This software is furnished under a license and may be used and copied
 * only in accordance with the terms of such license and with the inclusion
 * of the above copyright notice. If you Purchased from Codecanyon,
 * Please read the full License from here - http://codecanyon.net/licenses/standard
 */

namespace App\Plugins\watermark;

use App\Models\Ad;
use App\Models\PaymentMethod;
use App\Models\Setting;
use Illuminate\Http\Request;
use App\Helpers\Payment;
use App\Models\Package;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;
use Omnipay\Omnipay;
use Illuminate\Support\Facades\Route;
use Prologue\Alerts\Facades\Alert;

class Watermark extends Payment
{
    /**
     * @param $image
     * @return null
     */
    public static function apply($image)
    {
        // Insert watermark at bottom-right corner with 10px offset
        try {
            $watermark = config('settings.watermark');
            if (!empty($watermark) and Storage::exists($watermark)) {
                $image->insert(Storage::get($watermark), config('watermark.position'), (int)config('watermark.position-x'), (int)config('watermark.position-y'));
            }
        } catch (\Exception $e) {
            return null;
        }

        return $image;
    }

    /**
     * @param $setting
     * @param null $currentValue
     * @return null|string
     */
    public static function getWatermarkValueHtml($setting, $currentValue = null)
    {
        if ($setting->key == 'watermark') {
            if (empty($setting->value) or !Storage::exists($setting->value)) {
                $out = '';
            } else {
                $out = '<img src="' . Storage::url($setting->value) . '" alt="' . $setting->value . '" style="width:100px; height:auto;"><br>';
            }
            $out .= '[<a href="' . url(config('larapen.admin.route_prefix', 'admin') . '/setting/' . $setting->id . '/edit') . '">Edit</a>]';

            return $out;
        }

        return $currentValue;
    }

    /**
     * @param $value
     * @param $setting
     * @return bool
     */
    public static function setWatermarkValue($value, $setting)
    {
        if (isset($setting->key) && $setting->key == 'watermark') {
            $path = null;
            $destination_path = 'app/logo';

            // if the image was erased
            if ($value == null) {
                // delete the image from disk
                Storage::delete($setting->value);

                // set null in the database column
                $path = null;
            }

            // if a base64 was sent, store it in the db
            if (starts_with($value, 'data:image')) {
                try {
                    // Make the image (Size: 150x150)
                    $image = Image::make($value)->resize((int)config('watermark.width'), (int)config('watermark.height'), function($constraint) {
                        $constraint->aspectRatio();
                        $constraint->upsize();
                    })->encode('png', (int)config('watermark.quality'));
                } catch (\Exception $e) {
                    Alert::error($e->getMessage())->flash();
                    $path = null;

                    return $path;
                }

                // Generate a filename.
                $filename = uniqid('watermark-') . '.png';

                // Store the image on disk.
                Storage::put($destination_path . '/' . $filename, $image->stream());

                // Save the path to the database
                $path = $destination_path . '/' . $filename;
            }

            return $path;
        }

        return $value;
    }

    /**
     * @return bool
     */
    public static function installed()
    {
        $setting = Setting::active()->where('key', 'watermark')->first();
        if (empty($setting)) {
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    public static function install()
    {
        // Remove the plugin entry
        self::uninstall();

        // Plugin data
        $data = [
            'key'         => 'watermark',
            'name'        => 'Watermark',
            'value'       => null,
            'description' => 'Watermark (extension: png,jpg)',
            'field'       => '{"name":"value","label":"Watermark","type":"image","upload":"true","disk":"uploads","default":""}',
            'parent_id'   => 0,
            'lft'         => 8,
            'rgt'         => 9,
            'depth'       => 1,
            'active'      => 1,
        ];

        try {
            // Create plugin data
            $setting = Setting::create($data);
            if (empty($setting)) {
                return false;
            }
        } catch (\Exception $e) {
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    public static function uninstall()
    {
        $deletedRows = Setting::where('key', 'watermark')->delete();
        if ($deletedRows <= 0) {
            return false;
        }

        return true;
    }
}
